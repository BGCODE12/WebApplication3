﻿namespace WebApplication3.Models
{
    public class Holiday
    {
        public int HolidayID { get; set; }
        public string HolidayName { get; set; } = string.Empty;
        public DateTime HolidayDate { get; set; }
    }
}
