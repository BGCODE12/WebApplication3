﻿namespace WebApplication3.Models
{
    public class LeaveType
    {
        public int LeaveTypeID { get; set; }
        public string TypeName { get; set; } = string.Empty;
    }
}
