namespace WebApplication3.Models.DTOs.Devices
{
    public class DeviceCreateDto
    {
        public string DeviceName { get; set; } = string.Empty;
        public string IPAddress { get; set; } = string.Empty;
    }
}

