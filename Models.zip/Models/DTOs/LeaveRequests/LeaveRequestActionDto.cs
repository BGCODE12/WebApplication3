namespace WebApplication3.Models.DTOs.LeaveRequests
{
    public class LeaveRequestActionDto
    {
        
        public int ApprovedByEmployeeID { get; set; }
    }
}