﻿namespace WebApplication3.Models.DTOs.Auth
{
    public class AuthLoginDto
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}
