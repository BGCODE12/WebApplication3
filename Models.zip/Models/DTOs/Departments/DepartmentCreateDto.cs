﻿namespace WebApplication3.Models.DTOs.Departments
{
    public class DepartmentCreateDto
    {
        public string DepartmentName { get; set; }
    }
}
