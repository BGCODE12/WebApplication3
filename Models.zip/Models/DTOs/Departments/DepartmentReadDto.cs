﻿namespace WebApplication3.Models.DTOs.Departments
{
    public class DepartmentReadDto
    {
        public int DepartmentID { get; set; }
        public string DepartmentName { get; set; }
    }
}
