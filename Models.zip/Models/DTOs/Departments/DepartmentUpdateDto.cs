﻿namespace WebApplication3.Models.DTOs.Departments
{
    public class DepartmentUpdateDto
    {
        public string DepartmentName { get; set; }
    }
}
