namespace WebApplication3.Models.DTOs.LeaveTypes
{
    public class LeaveTypeUpdateDto
    {
        public string TypeName { get; set; } = string.Empty;
    }
}

