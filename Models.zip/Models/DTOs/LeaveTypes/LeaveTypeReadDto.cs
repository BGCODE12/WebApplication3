namespace WebApplication3.Models.DTOs.LeaveTypes
{
    public class LeaveTypeReadDto
    {
        public int LeaveTypeID { get; set; }
        public string TypeName { get; set; } = string.Empty;
    }
}

