namespace WebApplication3.Models.DTOs.LeaveTypes
{
    public class LeaveTypeCreateDto
    {
        public string TypeName { get; set; } = string.Empty;
    }
}

